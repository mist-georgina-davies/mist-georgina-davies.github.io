function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6JAWIimSFnt":
        Script1();
        break;
      case "5VJDoVAaMfk":
        Script2();
        break;
      case "5m3OfwF3NIn":
        Script3();
        break;
      case "5s5UtZ2wNwK":
        Script4();
        break;
      case "6jcYKJ9Pbfc":
        Script5();
        break;
      case "6TiMF8uaxju":
        Script6();
        break;
      case "6pJ52Wl9wpf":
        Script7();
        break;
      case "6hnJhBNTl5y":
        Script8();
        break;
      case "6fJkiMMGleR":
        Script9();
        break;
      case "6Q429SFMEXJ":
        Script10();
        break;
      case "6VFEDZJy3BU":
        Script11();
        break;
      case "5yedKoK4Owe":
        Script12();
        break;
      case "5v2KXS7LbtB":
        Script13();
        break;
      case "60y0OxE9BUc":
        Script14();
        break;
      case "5oN1lwIA9W5":
        Script15();
        break;
      case "64BN8HNc5o2":
        Script16();
        break;
      case "5l6ZSJ6MamR":
        Script17();
        break;
      case "5mbhtZvGKTb":
        Script18();
        break;
  }
}

function Script1()
{
  var player = GetPlayer();
var totalSlides = player.GetVar("TotalSlides");
var slideNumberText = "Slide " + player.slideIndex + " of " + totalSlides;
player.SetVar("SlideNumberText", slideNumberText);
}

function Script2()
{
  var player = GetPlayer();
var totalSlides = player.GetVar("TotalSlides");
var slideNumberText = "Slide " + player.slideIndex + " of " + totalSlides;
player.SetVar("SlideNumberText", slideNumberText);
}

function Script3()
{
  var player = GetPlayer();
var totalSlides = player.GetVar("TotalSlides");
var slideNumberText = "Slide " + player.slideIndex + " of " + totalSlides;
player.SetVar("SlideNumberText", slideNumberText);
}

function Script4()
{
  var player = GetPlayer();
var totalSlides = player.GetVar("TotalSlides");
var slideNumberText = "Slide " + player.slideIndex + " of " + totalSlides;
player.SetVar("SlideNumberText", slideNumberText);
}

function Script5()
{
  var player = GetPlayer();
var totalSlides = player.GetVar("TotalSlides");
var slideNumberText = "Slide " + player.slideIndex + " of " + totalSlides;
player.SetVar("SlideNumberText", slideNumberText);
}

function Script6()
{
  var player = GetPlayer();
var totalSlides = player.GetVar("TotalSlides");
var slideNumberText = "Slide " + player.slideIndex + " of " + totalSlides;
player.SetVar("SlideNumberText", slideNumberText);
}

function Script7()
{
  var player = GetPlayer();
var totalSlides = player.GetVar("TotalSlides");
var slideNumberText = "Slide " + player.slideIndex + " of " + totalSlides;
player.SetVar("SlideNumberText", slideNumberText);
}

function Script8()
{
  var player = GetPlayer();
var totalSlides = player.GetVar("TotalSlides");
var slideNumberText = "Slide " + player.slideIndex + " of " + totalSlides;
player.SetVar("SlideNumberText", slideNumberText);
}

function Script9()
{
  var player = GetPlayer();
var totalSlides = player.GetVar("TotalSlides");
var slideNumberText = "Slide " + player.slideIndex + " of " + totalSlides;
player.SetVar("SlideNumberText", slideNumberText);
}

function Script10()
{
  var player = GetPlayer();
var totalSlides = player.GetVar("TotalSlides");
var slideNumberText = "Slide " + player.slideIndex + " of " + totalSlides;
player.SetVar("SlideNumberText", slideNumberText);
}

function Script11()
{
  var player = GetPlayer();
var totalSlides = player.GetVar("TotalSlides");
var slideNumberText = "Slide " + player.slideIndex + " of " + totalSlides;
player.SetVar("SlideNumberText", slideNumberText);
}

function Script12()
{
  var player = GetPlayer();
var totalSlides = player.GetVar("TotalSlides");
var slideNumberText = "Slide " + player.slideIndex + " of " + totalSlides;
player.SetVar("SlideNumberText", slideNumberText);
}

function Script13()
{
  var player = GetPlayer();
var totalSlides = player.GetVar("TotalSlides");
var slideNumberText = "Slide " + player.slideIndex + " of " + totalSlides;
player.SetVar("SlideNumberText", slideNumberText);
}

function Script14()
{
  var player = GetPlayer();
var totalSlides = player.GetVar("TotalSlides");
var slideNumberText = "Slide " + player.slideIndex + " of " + totalSlides;
player.SetVar("SlideNumberText", slideNumberText);
}

function Script15()
{
  var player = GetPlayer();
var totalSlides = player.GetVar("TotalSlides");
var slideNumberText = "Slide " + player.slideIndex + " of " + totalSlides;
player.SetVar("SlideNumberText", slideNumberText);
}

function Script16()
{
  var player = GetPlayer();
var totalSlides = player.GetVar("TotalSlides");
var slideNumberText = "Slide " + player.slideIndex + " of " + totalSlides;
player.SetVar("SlideNumberText", slideNumberText);
}

function Script17()
{
  var player = GetPlayer();
var totalSlides = player.GetVar("TotalSlides");
var slideNumberText = "Slide " + player.slideIndex + " of " + totalSlides;
player.SetVar("SlideNumberText", slideNumberText);
}

function Script18()
{
  var player = GetPlayer();
var totalSlides = player.GetVar("TotalSlides");
var slideNumberText = "Slide " + player.slideIndex + " of " + totalSlides;
player.SetVar("SlideNumberText", slideNumberText);
}

