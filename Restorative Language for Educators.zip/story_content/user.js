function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5tveRoEsfxi":
        Script1();
        break;
      case "6dO2oYoOgog":
        Script2();
        break;
      case "5gt97XS88qa":
        Script3();
        break;
      case "6B6tSqdlBC3":
        Script4();
        break;
      case "61W6IHnieY4":
        Script5();
        break;
      case "6lnI3ArYvg6":
        Script6();
        break;
      case "6e134ZbSQSS":
        Script7();
        break;
      case "5weX7nbqQWR":
        Script8();
        break;
      case "6F5bAiyppX5":
        Script9();
        break;
      case "6eWfenZRRSB":
        Script10();
        break;
      case "5bUcxSHFRk5":
        Script11();
        break;
      case "5kaXsTwtoCK":
        Script12();
        break;
      case "6aefQ9fVSXE":
        Script13();
        break;
      case "5a8rnWUjDqf":
        Script14();
        break;
      case "5hKuDphzCTP":
        Script15();
        break;
      case "6CutKXr3h09":
        Script16();
        break;
      case "65UYpxHCr6t":
        Script17();
        break;
      case "66JIiNGPr9n":
        Script18();
        break;
      case "5wGdzOjO7j6":
        Script19();
        break;
      case "6ETGfjAaWqc":
        Script20();
        break;
      case "5msgv8V9ql4":
        Script21();
        break;
      case "6oE23QvgFZc":
        Script22();
        break;
      case "6mctziD88Sm":
        Script23();
        break;
      case "5sx7SPwZwA6":
        Script24();
        break;
      case "6irA035jzCQ":
        Script25();
        break;
      case "5sNDT1oofNp":
        Script26();
        break;
      case "6lXN5iHD43k":
        Script27();
        break;
      case "6rb5KLJ21y6":
        Script28();
        break;
      case "6QeRFCLho3a":
        Script29();
        break;
      case "6MSFIjYXAM2":
        Script30();
        break;
      case "6BwQG90xwSK":
        Script31();
        break;
  }
}

function Script1()
{
  var player = GetPlayer();
var totalSlides = player.GetVar("TotalSlides");
var slideNumberText = "Slide " + player.slideIndex + " of " + totalSlides;
player.SetVar("SlideNumberText", slideNumberText);
}

function Script2()
{
  var player = GetPlayer();
var totalSlides = player.GetVar("TotalSlides");
var slideNumberText = "Slide " + player.slideIndex + " of " + totalSlides;
player.SetVar("SlideNumberText", slideNumberText);
}

function Script3()
{
  var player = GetPlayer();
var totalSlides = player.GetVar("TotalSlides");
var slideNumberText = "Slide " + player.slideIndex + " of " + totalSlides;
player.SetVar("SlideNumberText", slideNumberText);
}

function Script4()
{
  var player = GetPlayer();
var totalSlides = player.GetVar("TotalSlides");
var slideNumberText = "Slide " + player.slideIndex + " of " + totalSlides;
player.SetVar("SlideNumberText", slideNumberText);
}

function Script5()
{
  var player = GetPlayer();
var totalSlides = player.GetVar("TotalSlides");
var slideNumberText = "Slide " + player.slideIndex + " of " + totalSlides;
player.SetVar("SlideNumberText", slideNumberText);
}

function Script6()
{
  var player = GetPlayer();
var totalSlides = player.GetVar("TotalSlides");
var slideNumberText = "Slide " + player.slideIndex + " of " + totalSlides;
player.SetVar("SlideNumberText", slideNumberText);
}

function Script7()
{
  var player = GetPlayer();
var totalSlides = player.GetVar("TotalSlides");
var slideNumberText = "Slide " + player.slideIndex + " of " + totalSlides;
player.SetVar("SlideNumberText", slideNumberText);
}

function Script8()
{
  var player = GetPlayer();
var totalSlides = player.GetVar("TotalSlides");
var slideNumberText = "Slide " + player.slideIndex + " of " + totalSlides;
player.SetVar("SlideNumberText", slideNumberText);
}

function Script9()
{
  var player = GetPlayer();
var totalSlides = player.GetVar("TotalSlides");
var slideNumberText = "Slide " + player.slideIndex + " of " + totalSlides;
player.SetVar("SlideNumberText", slideNumberText);
}

function Script10()
{
  var player = GetPlayer();
var totalSlides = player.GetVar("TotalSlides");
var slideNumberText = "Slide " + player.slideIndex + " of " + totalSlides;
player.SetVar("SlideNumberText", slideNumberText);
}

function Script11()
{
  var player = GetPlayer();
var totalSlides = player.GetVar("TotalSlides");
var slideNumberText = "Slide " + player.slideIndex + " of " + totalSlides;
player.SetVar("SlideNumberText", slideNumberText);
}

function Script12()
{
  var player = GetPlayer();
var totalSlides = player.GetVar("TotalSlides");
var slideNumberText = "Slide " + player.slideIndex + " of " + totalSlides;
player.SetVar("SlideNumberText", slideNumberText);
}

function Script13()
{
  var player = GetPlayer();
var totalSlides = player.GetVar("TotalSlides");
var slideNumberText = "Slide " + player.slideIndex + " of " + totalSlides;
player.SetVar("SlideNumberText", slideNumberText);
}

function Script14()
{
  var player = GetPlayer();
var totalSlides = player.GetVar("TotalSlides");
var slideNumberText = "Slide " + player.slideIndex + " of " + totalSlides;
player.SetVar("SlideNumberText", slideNumberText);
}

function Script15()
{
  var player = GetPlayer();
var totalSlides = player.GetVar("TotalSlides");
var slideNumberText = "Slide " + player.slideIndex + " of " + totalSlides;
player.SetVar("SlideNumberText", slideNumberText);
}

function Script16()
{
  var player = GetPlayer();
var totalSlides = player.GetVar("TotalSlides");
var slideNumberText = "Slide " + player.slideIndex + " of " + totalSlides;
player.SetVar("SlideNumberText", slideNumberText);
}

function Script17()
{
  var player = GetPlayer();
var totalSlides = player.GetVar("TotalSlides");
var slideNumberText = "Slide " + player.slideIndex + " of " + totalSlides;
player.SetVar("SlideNumberText", slideNumberText);
}

function Script18()
{
  var player = GetPlayer();
var totalSlides = player.GetVar("TotalSlides");
var slideNumberText = "Slide " + player.slideIndex + " of " + totalSlides;
player.SetVar("SlideNumberText", slideNumberText);
}

function Script19()
{
  var player = GetPlayer();
var totalSlides = player.GetVar("TotalSlides");
var slideNumberText = "Slide " + player.slideIndex + " of " + totalSlides;
player.SetVar("SlideNumberText", slideNumberText);
}

function Script20()
{
  var player = GetPlayer();
var totalSlides = player.GetVar("TotalSlides");
var slideNumberText = "Slide " + player.slideIndex + " of " + totalSlides;
player.SetVar("SlideNumberText", slideNumberText);
}

function Script21()
{
  var player = GetPlayer();
var totalSlides = player.GetVar("TotalSlides");
var slideNumberText = "Slide " + player.slideIndex + " of " + totalSlides;
player.SetVar("SlideNumberText", slideNumberText);
}

function Script22()
{
  var player = GetPlayer();
var totalSlides = player.GetVar("TotalSlides");
var slideNumberText = "Slide " + player.slideIndex + " of " + totalSlides;
player.SetVar("SlideNumberText", slideNumberText);
}

function Script23()
{
  var player = GetPlayer();
var totalSlides = player.GetVar("TotalSlides");
var slideNumberText = "Slide " + player.slideIndex + " of " + totalSlides;
player.SetVar("SlideNumberText", slideNumberText);
}

function Script24()
{
  var player = GetPlayer();
var totalSlides = player.GetVar("TotalSlides");
var slideNumberText = "Slide " + player.slideIndex + " of " + totalSlides;
player.SetVar("SlideNumberText", slideNumberText);
}

function Script25()
{
  var player = GetPlayer();
var totalSlides = player.GetVar("TotalSlides");
var slideNumberText = "Slide " + player.slideIndex + " of " + totalSlides;
player.SetVar("SlideNumberText", slideNumberText);
}

function Script26()
{
  var player = GetPlayer();
var totalSlides = player.GetVar("TotalSlides");
var slideNumberText = "Slide " + player.slideIndex + " of " + totalSlides;
player.SetVar("SlideNumberText", slideNumberText);
}

function Script27()
{
  var player = GetPlayer();
var totalSlides = player.GetVar("TotalSlides");
var slideNumberText = "Slide " + player.slideIndex + " of " + totalSlides;
player.SetVar("SlideNumberText", slideNumberText);
}

function Script28()
{
  var player = GetPlayer();
var totalSlides = player.GetVar("TotalSlides");
var slideNumberText = "Slide " + player.slideIndex + " of " + totalSlides;
player.SetVar("SlideNumberText", slideNumberText);
}

function Script29()
{
  var player = GetPlayer();
var totalSlides = player.GetVar("TotalSlides");
var slideNumberText = "Slide " + player.slideIndex + " of " + totalSlides;
player.SetVar("SlideNumberText", slideNumberText);
}

function Script30()
{
  var player = GetPlayer();
var totalSlides = player.GetVar("TotalSlides");
var slideNumberText = "Slide " + player.slideIndex + " of " + totalSlides;
player.SetVar("SlideNumberText", slideNumberText);
}

function Script31()
{
  var player = GetPlayer();
var totalSlides = player.GetVar("TotalSlides");
var slideNumberText = "Slide " + player.slideIndex + " of " + totalSlides;
player.SetVar("SlideNumberText", slideNumberText);
}

